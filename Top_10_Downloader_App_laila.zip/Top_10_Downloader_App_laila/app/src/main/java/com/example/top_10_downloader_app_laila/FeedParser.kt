package com.example.top_10_downloader_app_laila

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class FeedParser {

    private val Details_list = ArrayList<Details>()

    var status = true
    var Entry = false
    var Value = ""

    fun parse(xmlData: String): Boolean {

        try {
            val Xml_Pull_Parser_Factory = XmlPullParserFactory.newInstance()
            Xml_Pull_Parser_Factory.isNamespaceAware = true
            val Pull_Parser = Xml_Pull_Parser_Factory.newPullParser()
            Pull_Parser.setInput(xmlData.reader())

            var event_Type = Pull_Parser.eventType
            var title = Details()
            while (event_Type != XmlPullParser.END_DOCUMENT) {

                val name = Pull_Parser.name

                when (event_Type) {

                    XmlPullParser.START_TAG -> {
                        if (name == "entry") {
                            Entry = true
                        }
                    }

                    XmlPullParser.TEXT -> Value = Pull_Parser.text

                    XmlPullParser.END_TAG -> {

                        if (Entry) {
                            when (name) {
                                "entry" -> {
                                    Details_list.add(title)
                                    Entry = false
                                    title = Details()
                                }

                                "name" -> title.title = Value

                            }
                        }


                    }
                }

                event_Type = Pull_Parser.next()

            }

        } catch (e: Exception) {
            e.printStackTrace()
            status = false
        }

        return status
    }

    fun getList(): ArrayList<Details> {

        return Details_list
    }
}