package com.example.top_10_downloader_app_laila

import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    lateinit var RecyclerView: RecyclerView
    lateinit var Button_Get: Button

    var Details_list = ArrayList<Details>()

    var URL =""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        RecyclerView = findViewById(R.id.Recycler_View)
        RecyclerView.layoutManager = LinearLayoutManager(this)

        Button_Get = findViewById(R.id.Button_Get)
        Button_Get.setOnClickListener {

            requestApi("http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=10/xml")

            RecyclerView = findViewById(R.id.Recycler_View)
            RecyclerView.layoutManager = LinearLayoutManager(this)
            RecyclerView.setHasFixedSize(true)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.top_10 -> {
                URL ="http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=10/xml"
                Toast.makeText(this,"10 DownloaderApp" , Toast.LENGTH_SHORT)
            }
            R.id.top_100 -> {
                URL = "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=100/xml"
                Toast.makeText(this,"100 DownloaderApp" , Toast.LENGTH_SHORT)
                var t =findViewById<TextView>(R.id.Text_View)
                t.text ="Top 100 Apps in APP Store"

            }
            else -> return super.onOptionsItemSelected(item)
        }
        requestApi(URL)
        RecyclerView = findViewById(R.id.Recycler_View)
        RecyclerView.layoutManager = LinearLayoutManager(this)
        RecyclerView.setHasFixedSize(true)
        return super.onOptionsItemSelected(item)
    }

    private fun XML(URL_Path: String?): String {
        val result = StringBuilder()

        try {
            val url = URL(URL_Path)
            val HUC: HttpURLConnection = url.openConnection() as HttpURLConnection

            val Buffered_Reader = BufferedReader(InputStreamReader(HUC.inputStream))

            val input = CharArray(500)
            var chars = 0
            while (chars >= 0) {
                chars = Buffered_Reader.read(input)
                if (chars > 0) {
                    result.append(String(input, 0, chars))
                }
            }
            Buffered_Reader.close()
            return result.toString()


        } catch (e: IOException) {
            Log.e(ContentValues.TAG, "Error")
        }
        return ""
    }

    private fun requestApi(URL: String) {

        CoroutineScope(Dispatchers.IO).launch {

            val feed = async {

                XML(URL)

            }.await()

            if (feed.isNotEmpty()) {
                val parse = async {

                    FeedParser()

                }.await()

                parse.parse(feed)
                Details_list = parse.getList()


                withContext(Dispatchers.Main) {


                    RecyclerView.adapter = Adapter(Details_list)
                    RecyclerView.adapter?.notifyDataSetChanged()

                }
            }
        }
    }
}