package com.example.top_10_downloader_app_laila

class Details {
    var title: String = ""


    override fun toString(): String {
        return """
            name = $title
           """.trimIndent()
    }
}